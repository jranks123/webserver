$(window).load(function() { 
    $('#rotatinglogo').fadeOut(); 
    $('#preloader').delay(350).fadeOut('slow');
    $('body').delay(950).css({'overflow':'visible'});
})
